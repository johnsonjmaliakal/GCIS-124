import java.util.HashMap;
import java.util.Map;

public class AdjacencyRedBlackGraph<E> implements RedBlackGraph<E> {

    private Map<E,RedBlackVertex<E>> vertices;

    public AdjacencyRedBlackGraph(){
        vertices = new HashMap<E,RedBlackVertex<E>>();
    }

    @Override
    public boolean contains(E item) { 
        return vertices.containsKey(item);
    }

    @Override
    public void connectDirected(E a, E b) {
        RedBlackVertex<E> va = vertices.get(a);
        RedBlackVertex<E> vb = vertices.get(b);
        va.connect(vb);
    }

    @Override
    public void connectUndirected(E a, E b) {
        RedBlackVertex<E> va = vertices.get(a);
        RedBlackVertex<E> vb = vertices.get(b);
        va.connect(vb);
        vb.connect(va);
    }

    @Override
    public int size() {
        return vertices.size();
    }

    @Override
    public void add(E item, boolean color) {
        // Auto-generated method stub - to be completed by the student

    }

    @Override
    public boolean isRed(E item) {
        // Auto-generated method stub - to be completed by the student
        return false;
    }

    @Override
    public boolean isBlack(E item) {
        // Auto-generated method stub - to be completed by the student
        return false;
    }

    @Override
    public boolean hasRedBlackPath(E a, E b) {
        // Auto-generated method stub - to be completed by the student
        return false;
    }

}
